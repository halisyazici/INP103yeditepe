jahr=int(input("Kaç yaşındsınız?"))
abschlussnote=int(input("Bitirme notunuz kaç?"))

if 50>=jahr>=20 and abschlussnote>80:
  print("İşe alındınız.")
else:
  print("Başvurunuz olumsuz değerlendirilmiştir.")